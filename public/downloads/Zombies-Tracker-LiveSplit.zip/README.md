# LiveSplit addon 1.1.1

Close LiveSplit and copy LiveSplit.ZombiesTracker.dll into its Components folder, replacing the old DLL. Reopen your existing saved layout. Keep your runner key and aliases.

Split aliases now have separate presets for each map and category. Choose a map and category in the alias editor, enter your mappings, Apply, then save the layout. Existing map-only mappings are copied into each compatible category on upgrade. Editing one category does not change another. Unmapped splits still use automatic detection.

The settings panel now fits smaller windows so you can scroll to its final controls.

Source code: https://github.com/PenguineSussy/zombies-tracker
