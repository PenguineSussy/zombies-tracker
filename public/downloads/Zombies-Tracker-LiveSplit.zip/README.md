# LiveSplit addon 1.1.3

Save your layout and close LiveSplit. Replace LiveSplit.ZombiesTracker.dll in Components, then reopen your saved layout. Existing runner keys, alias presets, and pending uploads are preserved.

The addon waits when completed split times disagree with the current timer instead of queuing an invalid update. Valid negative countdown checkpoints remain supported.

The server preserves replayed snapshots with future checkpoint times in a private recovery archive, without counting them as runs or sending alerts, so newer valid uploads can continue. Do not discard the pending queue. Replaying a large backlog may take time.

Source: https://github.com/PenguineSussy/zombies-tracker
