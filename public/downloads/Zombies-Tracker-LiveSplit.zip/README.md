# LiveSplit addon 1.1.2

Save your layout and close LiveSplit. Copy LiveSplit.ZombiesTracker.dll into LiveSplit's Components folder, replacing the old DLL. Reopen your saved layout. Existing keys and alias presets are preserved.

This update caches settings and alias presets to reduce repeated UI processing, moves full saved-history scans from Start/Split/Reset handlers to the next heartbeat, and skips unchanged files during saved-PB folder scans. Run events still upload immediately; saved comparisons may follow on the next heartbeat.

Source code: https://github.com/PenguineSussy/zombies-tracker
